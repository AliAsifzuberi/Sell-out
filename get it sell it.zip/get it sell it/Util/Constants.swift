//
//  Constants.swift
//  get it sell it
//
//  Created by Ali Zuberi  on 2018-02-15.
//  Copyright © 2018 Ali Zuberi . All rights reserved.
//

import UIKit
import CoreLocation
import MapKit
// for the shadows
let SHADOW_GRAY: CGFloat = 120.0 / 255.0
// user id
let KEY_UID = "uid"


