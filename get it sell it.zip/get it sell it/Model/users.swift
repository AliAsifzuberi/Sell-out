//
//  users.swift
//  get it sell it
//
//  Created by Ali Zuberi  on 2018-07-02.
//  Copyright © 2018 Ali Zuberi . All rights reserved.
//

import Foundation


class users {
    private var _email: String!
    private var _username: String!
    private var _profileURl: String!
    private var _uid: String!
    
    
    var uid : String {
        return _uid
    }
    
    
    var email :String {
        return _email
        
    }
    
    var username: String {
        return _username
    }
    
    var profileURL : String {
        return _profileURl
    }
    
    init(email:String, username:String , profileURL:String, uid:String) {
        self._email = email
        self._username = username
        self._uid = uid
       self._profileURl = profileURL
    }
    
    init(uid: String , dictionary: [String: Any]) {
        self._uid = uid
        
        if let username = dictionary["username"] as? String {
            self._username = username
        }
        
        if let email = dictionary["email"] as? String {
            self._email = email
        }
        
        if let profileURL = dictionary["profileURL"] as? String {
            self._profileURl = profileURL
        }
        
        
        
    }
}
