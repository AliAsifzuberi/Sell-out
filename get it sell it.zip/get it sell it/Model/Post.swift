//
//  Post.swift
//  get it sell it
//
//  Created by Ali Zuberi  on 2018-03-15.
//  Copyright © 2018 Ali Zuberi . All rights reserved.
//

import Foundation
import CoreLocation
// parsing data from firebase databse
class Post {
    private var _caption : String!
    private var _imageUrl: String!
    private var _likes: Int!
    private var _price: Int!
    private var _postKey: String!
    private var _address: CLLocationCoordinate2D!
    private var _lat: Double!
    private var _long: Double!
    private var _title: String!
    
    var caption: String {
        return _caption
    }
    
    var imageUrl: String{
        return _imageUrl
    }
    
    var likes: Int {
        return _likes
    }
    
    var price : Int {
        return _price
    }
    
    var postKey: String {
        return _postKey
    }
    var address: CLLocationCoordinate2D {
        return _address
    }
    var lat: Double {
      return _lat
    }
    
    var long : Double {
       return _long
    }
    var title: String {
        return _title
    }
    
    init(caption: String, imageUrl: String, likes: Int, price:Int, address: CLLocationCoordinate2D,title: String, lat: Double , long: Double) {
        self._caption = caption
        self._imageUrl = caption
        self._likes = likes
        self._price = price
        self._address = address
        self._long = long
        self._lat = lat
        self._title = title
    }
    
    init(postKey: String, postData: Dictionary<String, AnyObject>) {
        self._postKey = postKey
        
        if let caption = postData["caption"] as? String {
            self._caption = caption
            
        }
        
        if let imageUrl = postData["imageUrl"] as? String {
            self._imageUrl = imageUrl
        }
        
        
        if let likes = postData["likes"] as? Int {
            
            self._likes = likes
        }
        
        if let price = postData["price"] as? Int {
            self._price = price
        }
        
        if let address = postData["address"] as? CLLocationCoordinate2D {
            self._address = address
        }
        
        if let long = postData["long"] as? Double {
            self._long = long
        }
        
        if let lat = postData["lat"] as? Double {
           self._lat = lat
        }
        
        if let title = postData["title"] as? String {
            self._title = title
        }
        
    }
    
    
    }

