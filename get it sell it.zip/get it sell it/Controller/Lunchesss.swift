//
//  LaunchScreen.swift
//  get it sell it
//
//  Created by Ali Zuberi  on 2018-11-03.
//  Copyright © 2018 Ali Zuberi . All rights reserved.
//

import UIKit
import Lottie

class Lunchesss: UIViewController {

    @IBOutlet weak var animationView: LOTAnimationView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        startit()
        
    }
    
    func startit(){
        animationView.setAnimation(named: "cart")
        animationView.play()
    }
    

}
