//
//  FeedVC.swift
//  get it sell it
//
//  Created by Ali Zuberi  on 2018-02-18.
//  Copyright © 2018 Ali Zuberi . All rights reserved.
//

import UIKit
import SwiftKeychainWrapper
import Firebase
import FirebaseDatabase
import GoogleMobileAds

class FeedVC: UIViewController,UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate{
    
    
    var resultsSearchController = UISearchController()
    @IBOutlet weak var searchBarrr: UISearchBar!
    @IBOutlet weak var tableView: UITableView!
    var interstital: GADInterstitial!
    var filtetedpost = [Post]()
    var posts = [Post]()
    var isSearching = false
    // creating a local cache
    @IBOutlet weak var Lblyou: UILabel!
    static var imageCache: NSCache<NSString, UIImage> = NSCache()
    
    let searchController = UISearchController(searchResultsController: nil)
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        //hideKeyboardWhenTappedAround()
        
        
        interstital = GADInterstitial(adUnitID: "ca-app-pub-6678323998837443/5953429170")
        let request = GADRequest()
        interstital.load(request)
      
        
        searchBarrr.isHidden = true
        
        tableView.reloadData()
        
        tableView.dataSource = self
        tableView.delegate = self
        
        searchBarrr.delegate  = self
        
      searchBarrr.returnKeyType = UIReturnKeyType.done
        
        interstital = creatAndLoadInterstial()
        
        //var inSearchMode = false
      
        
        
        
        
    
        // obseriving the databse for changes or for new posts
        
        Database.database().reference().child("posts").observe(.value) { (snapshot) in
            if let  snapshot = snapshot.children.allObjects as? [DataSnapshot] {
                for snap in snapshot{
                    print("SNAP:\(snap)")
                    if let postDict = snap.value as? Dictionary<String, AnyObject> {
                        let key = snap.key
                        let post = Post(postKey: key, postData: postDict)
                        self.posts.append(post)
                    }
                }
                
                }
                // reload tableview when find changes and updates
                self.tableView.reloadData()
            }
        
        
        
    }
    
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if searchBarrr.text != "" {
            return filtetedpost.count
        }
    
        
        return posts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let post: Post
        
        
        if  let  cell = tableView.dequeueReusableCell(withIdentifier: "PostCell") as? PostCell {
            
            
            if isSearching == true {
                post = filtetedpost[indexPath.row]
                if let img = FeedVC.imageCache.object(forKey: post.imageUrl as NSString) {
                    
                    cell.configureCell(post: post, img: img)
                }
                
                return cell
            } else {
            
            post = posts[indexPath.row]
            
            // check if image exits in the cache 
           
            
            if let img = FeedVC.imageCache.object(forKey: post.imageUrl as NSString) {
                cell.configureCell(post: post, img: img)
                
                return cell
            } else {
                
                cell.configureCell(post: post, img : nil)
                
              //  cell.layer.cornerRadius = 10
                
                return cell
                
            }
            
        
        
        return PostCell()
        
        }
        
        
      
        
        
    }
        return PostCell()
        
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if interstital.isReady{
            interstital.present(fromRootViewController: self)
        } else {
            print("AD wasn't ready")
        }
        performSegue(withIdentifier: "ToPostDetail", sender: posts[indexPath.row])
    }
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let guest = segue.destination as? PosttitleVC
        
        guest?.post = sender as? AnyObject as? Post
            
        
    }
    
  
  
    
  
    
  
    
    
    @IBAction func signOutTapped(_ sender: Any) {
        
      let removeSuccessful: Bool = KeychainWrapper.standard.removeObject(forKey:KEY_UID)
        print("ID HAS BEEN REMVOED")
        try! Auth.auth().signOut()
        performSegue(withIdentifier: "goToSignIn", sender: nil)
    
    

    
    
    
}
    
    
    
    @IBAction func cameraBtnPressed(_ sender: Any) {
        
        
        
        performSegue(withIdentifier: "SecondviewSegue", sender: nil)
    }
    
    
    
    
    @IBAction func searchpressed(_ sender: Any) {
        searchBarrr.isHidden = false
        Lblyou.isHidden = true
        
       var inSearchMode = false
    
        
        
        
    }
    
    
    
    
    
    
    func creatAndLoadInterstial() -> GADInterstitial {
        var interstital = GADInterstitial(adUnitID: "ca-app-pub-6678323998837443/5953429170")
     
        interstital.load(GADRequest())
        return interstital
    }
    
    func interstitalDidDismissScreen(_ ad: GADInterstitial) {
        interstital = creatAndLoadInterstial()
    }
    
    
 
    
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchBarrr.text == nil || searchBarrr.text == "" {
            
                     isSearching = false
            
                     tableView.reloadData()
            
                      view.endEditing(true)
            
    
        }else {
            
            isSearching = true
                 let lower = searchBarrr.text!.lowercased()
            
            filtetedpost = posts.filter({$0.title.range(of: lower) != nil})
            tableView.reloadData()
            print(filtetedpost)

                  }
        
    
        }
    
    
    
        
        
        }
        

  
    

    






