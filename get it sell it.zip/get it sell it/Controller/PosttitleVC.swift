//
//  PosttitleVC.swift
//  get it sell it
//
//  Created by Ali Zuberi  on 2018-03-12.
//  Copyright © 2018 Ali Zuberi . All rights reserved.
//

import UIKit
import Firebase
import MapKit
import CoreLocation

class PosttitleVC: UIViewController, CLLocationManagerDelegate {
    
    
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var Caption: UITextView!
    
    @IBOutlet weak var postImg: UIImageView!
    
    static var imageCache: NSCache<NSString, UIImage> = NSCache()
    
    
   var post:Post!
    
    var img: UIImage!
    
    var map: MKMapView!
    
    let annotation = MKPointAnnotation()
    
    

     let locationManger = CLLocationManager()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.Caption.text = post.caption
        
        hideKeyboardWhenTappedAround()
        
        
        self.mapView.showsBuildings = true
        self.mapView.isZoomEnabled = true
        self.mapView.showsTraffic = true
        //self.mapView.showsUserLocation = true
  print(post.lat)
    print(post.long)
        
        locationManger.delegate = self
        
        var location = CLLocationCoordinate2DMake(post.lat, post.long)
        
        
        var annotation = MKPointAnnotation()
        
        annotation.coordinate = location
        
        
        annotation.title = post.title
        
        annotation.subtitle = "$\(post.price)"
        
        mapView.addAnnotation(annotation)
        
        let center = CLLocationCoordinate2DMake(post.lat, post.long)
        let span = MKCoordinateSpanMake(0.01, 0.01)
        let region = MKCoordinateRegion(center: center, span: span)
        
        self.mapView.setRegion(region, animated: true)
        
        
    
    
        if img != nil {
            self.postImg.image = img
            
        } else {
            // downloading  image if not in cache
            
            
            let ref = Storage.storage().reference(forURL: post.imageUrl)
            
            // make sure is image is only 2 megabytes
            ref.getData(maxSize: 2 * 1024 * 1024, completion: { (data , error) in
                
                
                
                
                if error != nil {
                    //  if there is an error
                    print(" ALI:Unable to downald image ")
                } else {
                    print("ALI:image downlaed from storage")
                    
                    // downlading images and saving them to cache
                    if let imgData = data {
                        if let img = UIImage(data: imgData) {
                            self.postImg.image = img
                            PosttitleVC.imageCache.setObject(img, forKey: self.post.imageUrl as NSString)
                            
                        }
                    }
                    
                    
                    
                }
                
                
            })
            
            
        }
       
}
    
    
  
    
    
    
    
    
    


}

