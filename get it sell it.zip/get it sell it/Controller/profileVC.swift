//
//  profileVC.swift
//  get it sell it
//
//  Created by Ali Zuberi  on 2018-07-13.
//  Copyright © 2018 Ali Zuberi . All rights reserved.
//

import UIKit
import Firebase
import FirebaseStorage
import FirebaseDatabase
import FirebaseAuth
import SwiftKeychainWrapper



class profileVC: UIViewController {

    @IBOutlet weak var circularrrimg: UIImageView!
    
    @IBOutlet weak var email12: UILabel!
    
    @IBOutlet weak var username12: UILabel!
    
     static var imageCache: NSCache<NSString, UIImage> = NSCache()
    
    var user: users!
    var img: UIImage!
    
    override func viewDidLoad() {
        getuser()
        super.viewDidLoad()

       
        circularrrimg.roundedImage()
        
       // let img = circularrrimg.image
        
        
       
    }
    
    
    
    
func getuser() {
        
        let uid = Auth.auth().currentUser!.uid
        if Auth.auth().currentUser != nil {
            DataService.ds.REF_USERS.child("users\(uid)").observeSingleEvent(of: .value, with: {(snapshot) in
                
                guard  let dict = snapshot.value as? [String: Any] else { return }
                
                
                
                let user = users(uid: uid, dictionary: dict)
                
                
                print("ali\(self.email12.text = Auth.auth().currentUser?.email)")
                
                self.username12.text = user.username
                
                if self.img == nil {
                    self.circularrrimg.image = self.img
                    print("IT worked")
                    
                } else {
                    // downloading  image if not in cache
                    
                    print("doing")
                    
                    
                    let ref = Storage.storage().reference(forURL: user.profileURL)
                    
                    // make sure is image is only 2 megabytes
                    ref.getData(maxSize: 50 * 2000 * 2000, completion: { (data , error) in
                        
                        //let img = UIImage(data: data!)
                       // self.circularrrimg.image = img
                        
                        
                        
                        if error != nil {
                            //  if there is an error
                            print(" ALI:Unable to downald image ")
                        } else {
                            print("ALI:image downlaed from storage")
                            
                            // downlading images and saving them to cache
                            if let imgData = data {
                                if let img = UIImage(data: imgData) {
                                    self.circularrrimg.image = img
                                    profileVC.imageCache.setObject(img, forKey: user.profileURL as NSString)
                                    self.circularrrimg.image = img
                                    
                                }
                            }
                            
                            
                            
                        }
                        
                        
                    })
                    
                    
                }
                
                
              //  self.circularrrimg.image = self.img
                
                
                
                
                
                
                
                
                
                
            })
            
            
            
        }
        
    }
    
    
    
    

   
    @IBAction func signoutTappeded(_ sender: Any) {
        let keychainResult = KeychainWrapper.defaultKeychainWrapper.removeObject(forKey: KEY_UID)
        print("Ali: ID removed from keychain \(keychainResult)")
        try! Auth.auth().signOut()
        performSegue(withIdentifier: "igotufromthep", sender: nil)
    }

}

