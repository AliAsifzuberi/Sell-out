//
//  scrolltryVC.swift
//  get it sell it
//
//  Created by Ali Zuberi  on 2018-07-08.
//  Copyright © 2018 Ali Zuberi . All rights reserved.
//

import UIKit

class scrolltryVC: UIViewController {
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

    
    }



}
