//
//  SignUpVCViewController.swift
//  get it sell it
//
//  Created by Ali Zuberi  on 2018-07-01.
//  Copyright © 2018 Ali Zuberi . All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseStorage
import FirebaseDatabase
import SwiftKeychainWrapper

class SignUpVCViewController: UIViewController,UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    
    var imagePicker: UIImagePickerController!
    var imageSelected = false
    
    
    
    
    @IBOutlet weak var emailSignUp: FancyField!
    @IBOutlet weak var usernameSignUp: FancyField!
    @IBOutlet weak var passwordSignUp: FancyField!
    @IBOutlet weak var imageRoud: UIImageView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       // imageRoud.image = UIImage(named:"Profile_avatar_placeholder_large")
        
        
        imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.allowsEditing = true
        
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: "dismissKeyboard")
        
        view.addGestureRecognizer(tap)
        self.hideKeyboardWhenTappedAround()
        
        imageRoud.roundedImage()
        
    }
 
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let image = info[UIImagePickerControllerEditedImage] as? UIImage {
            imageRoud.image = image
            imageSelected = true
        } else {
            print("ALI:IMAGE WAS NOT SELECTED")
            
        
            
        }
        
        imagePicker.dismiss(animated: true, completion: nil)
    }
    
    
    
    
    @IBAction func chgProfilPicTapped(_ sender: Any) {
        
        present(imagePicker, animated: true, completion: nil)
        
        
    }
    
    
    
    
    
    @IBAction func SignupTpped(_ sender: Any) {
        
        
        
        if let email = emailSignUp.text, let password = passwordSignUp.text {
            Auth.auth().createUser(withEmail: email, password: password, completion: {(user,error) in
                
                if let user = user {
                    print(Auth.auth().currentUser!.uid)
                    let userData = ["provider": user.providerID]
                    self.completeSignIn(id: user.uid, userData: userData)
                    let imgUID = Auth.auth().currentUser!.uid
                    
                
            
                    
                    
                    guard let img = self.imageRoud.image else{
                       let img = UIImage(named: "Profile_avatar_placeholder_large.png")
                        
                         self.imageRoud.image = img
                        return
                        
                        
                        }

                    
                    
                    
                        
                    
                   
                    
                   
                    
                    
                    
                    
                    if let imageData = UIImageJPEGRepresentation(img, 0.2) {
                        
                        let imgUID = NSUUID().uuidString
                        
                        let newMetadata = StorageMetadata()
                        newMetadata.contentType = "imgae/jpeg"
                        
                        
                       DataService.ds.REF_PROFILE_IMAGES.child(imgUID).putData(imageData, metadata: newMetadata) { (newMetadata, error) in
                            if error != nil {
                                print("ALI: unabel to upload imgae")
                            } else {
                                print("ALI: succesfully uplaoded")
                                // getting download url
                                let downloadUrl = newMetadata?.downloadURL()!.absoluteString
                                self.posttofirebase(imgUrl: downloadUrl!)
                            }
                        }
                    }
                    
                    
                    
                }

            })
            
            
        }

}
    
    
    
    func completeSignIn(id: String, userData: Dictionary<String, String>) {
       // DataService.ds.createFirbaseDBUser(uid: id, userData: userData)
        //let keychainResult = KeychainWrapper.setString(id, forKey: KEY_UID)
        let keychainResult = KeychainWrapper.defaultKeychainWrapper.set(id, forKey: KEY_UID)
        print("aass: Data saved to keychain \(keychainResult)")
        performSegue(withIdentifier: "iden", sender: nil)
    }
    
   func posttofirebase(imgUrl: String) {
        let user : Dictionary<String, AnyObject> = [
           "username":usernameSignUp.text as AnyObject,
            "profileURL": imgUrl as AnyObject,
           "email":Auth.auth().currentUser!.email as AnyObject
            
            
        ]
    
        let uid = Auth.auth().currentUser!.uid
        
       let databaseref = DataService.ds.REF_USERS.child("users\(uid)")
        
    databaseref.setValue(user)
        
    
    }
    
    
    
 
    

}

