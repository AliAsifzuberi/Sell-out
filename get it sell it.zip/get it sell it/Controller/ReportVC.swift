//
//  ReportVC.swift
//  get it sell it
//
//  Created by Ali Zuberi  on 2018-10-20.
//  Copyright © 2018 Ali Zuberi . All rights reserved.
//

import UIKit

class ReportVC: UIViewController {
    
    
    @IBOutlet weak var reportFeild: FancyField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        reportFeild.textAlignment = .left
        reportFeild.contentVerticalAlignment = .top

        // Do any additional setup after loading the view.
    }
    

   
}
