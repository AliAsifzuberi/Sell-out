//
//  profiletestVC.swift
//  get it sell it
//
//  Created by Ali Zuberi  on 2018-11-24.
//  Copyright © 2018 Ali Zuberi . All rights reserved.
//

import Foundation
import UIKit
import Firebase
import FirebaseStorage
import FirebaseDatabase
import FirebaseAuth
import SwiftKeychainWrapper
import FirebaseStorageUI

class profiletestVC: UIViewController {
    
    override func viewDidLoad() {
        
    }
    
    if circularrrimg != nil {
    self.circularrrimg.image = img
    print("IT worked")
    
    } else {
    // downloading  image if not in cache
    
    
    
    
    let ref = Storage.storage().reference(forURL: user.profileURL)
    
    // make sure is image is only 2 megabytes
    ref.getData(maxSize: 50 * 2000 * 2000, completion: { (data , error) in
    
    
    
    
    if error != nil {
    //  if there is an error
    print(" ALI:Unable to downald image ")
    } else {
    print("ALI:image downlaed from storage")
    
    // downlading images and saving them to cache
    if let imgData = data {
    if let img = UIImage(data: imgData) {
    self.circularrrimg.image = img
    profileVC.imageCache.setObject(img, forKey: self.user.profileURL as NSString)
    
    }
    }
    
    
    
    }
    
    
    })
    
    
    }
    
    
    
    
    
    
    
    
    
}

    




