//
//  PostVC.swift
//  get it sell it
//
//  Created by Ali Zuberi  on 2018-02-19.
//  Copyright © 2018 Ali Zuberi . All rights reserved.
//

import UIKit
import Firebase
import FirebaseStorage
import FBSDKLoginKit
import FBSDKCoreKit
import SwiftKeychainWrapper
import GeoFire
import FirebaseDatabase
import CoreLocation
import MapKit


class PostVC: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate,CLLocationManagerDelegate {
    
    var imagePicker: UIImagePickerController!
    
    var imageSelected = false
    
   
    
    @IBOutlet weak var imageAdd: UIImageView!
    
    var locManager = CLLocationManager()
    
    var currentLocation: CLLocation!
    
    
    
  
    let numberFormatter = NumberFormatter()
    
    
   
    
    @IBOutlet weak var titelLbl: FancyField!
    @IBOutlet weak var priceLbl: FancyField!
    @IBOutlet weak var captionLbl: FancyField!
    
   @IBOutlet weak var postalCodeLbl: FancyField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        captionLbl.textAlignment = .left
        captionLbl.contentVerticalAlignment = .top
        
        hideKeyboardWhenTappedAround()
        
        imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.allowsEditing = true
       
        //manager.stopUpdatingLocation()
        locManager.requestWhenInUseAuthorization()
        locManager.delegate = self
    //locManager.startUpdatingLocation()
        
         let numberFormatter = NumberFormatter()
    
        
        
        
        
        
      
        

        
    }
    // once u selected the image get rid of the image picker
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
       // check if we are getting an image back and not a video or something
        if let image = info[UIImagePickerControllerEditedImage] as? UIImage{
            // set the image of the btn to that imaage
           imageAdd.image = image
            imageSelected = true
        }else {
            print("Iamge was not selected")
        }
        
        imagePicker.dismiss(animated: true, completion: nil)
    }
    
    
    
    @IBAction func addImageTapped(_ sender: Any) {
        
        
        present(imagePicker, animated: true, completion: nil)
        
    }
    
    
    
    @IBAction func postBtnTapped(_ sender: Any) {
        // check if user filled out all information
        if let title = titelLbl.text , let price = priceLbl.text , let  captiontext = captionLbl.text  {
            print("Ali: \(title) ,\(price) ,\(captiontext)")
        }else{
            
            // to do : user alert || add geofire || change all to guard statments
            print("plz fill out all information")
        }
        
        guard let img = imageAdd.image, imageSelected  else {
            print("plz enter an image plz i really mean it plz do it plz do it do it not pls did u do it plz tell me you ")
              return
        }
    
        
        
        
        
     
            currentLocation = locManager.location
      //    var  lat =  currentLocation.coordinate.latitude
       //    var long = currentLocation.coordinate.longitude
            
        
            
        
       
        
       // label1.text = "\(currentLocation.coordinate.longitude)"
       // label2.text = "\(currentLocation.coordinate.latitude)"
        
        
        // converting img into img Data and c=making it into a jpeg and compressing
        if let imgData = UIImageJPEGRepresentation(img, 0.2) {
            // geting a unique identifer
            let imgUid = NSUUID().uuidString
            
            // create file metadata telling firebase what type of data it is
            let newMetadata = StorageMetadata()
            newMetadata.contentType = "image/jpeg"
           
            
            
            
            
            // uploading image to firebase
            
            NetService.ds.REF_POST_IMAGES.child(imgUid).putData(imgData, metadata: newMetadata) { (newMetadata, error) in
                if error != nil {
                    print("ALI: unabel to upload imgae")
                } else {
                    print("ALI: succesfully uplaoded")
                    // getting download url
                    let downloadUrl = newMetadata?.downloadURL()?.absoluteString
                    //self.forwardGeocoding(postalCode: self.postalCodeLbl.text!, listingId: imgUid)
                    self.postToFirebase(imgUrl: downloadUrl!)
                    //self.locationManager
                                    }
            }
                
            }
            
        }
    
    func postToFirebase(imgUrl: String) {
        
        let price = priceLbl.text
        
         let numberFormatter = NumberFormatter()
        numberFormatter.numberStyle = .none
        
        let pricestring = numberFormatter.number(from: price!)
        
        
        
        // creating dictinoay for post
        let post: Dictionary<String, AnyObject> = [
            "caption": captionLbl.text as AnyObject,
            "imageUrl": imgUrl as AnyObject,
            "likes": 0 as AnyObject,
            "price": Int(price!) as! NSNumber,
            "title": titelLbl.text as AnyObject,
            "address": "\(currentLocation!)" as  AnyObject,
           "lat":currentLocation.coordinate.latitude as NSNumber,
           "long":currentLocation.coordinate.longitude as NSNumber
            
            
            
        ]
        
        // posting to firebase
        
        
        // refernce to what end point we want to post to
        // byAutoId creates an automatic post key
        let firebasePost = DataService.ds.REF_POSTS.childByAutoId()
        // writes the data to the firebase database to the location ref.post
        firebasePost.setValue(post)
        
        print("done")
        
        
        
        performSegue(withIdentifier:"goooback" , sender: nil)
        
        
        
        
        
    }
    
  
    }
    
    
    
            


    


