//
//  LogIn.swift
//  get it sell it
//
//  Created by Ali Zuberi  on 2018-07-01.
//  Copyright © 2018 Ali Zuberi . All rights reserved.
//

import UIKit
import Firebase
import FirebaseStorage
import FirebaseAuth
import FirebaseDatabase
import SwiftKeychainWrapper
import GoogleMobileAds

class LogVC: UIViewController {
    
    

    
    @IBOutlet weak var emailField: FancyField!
    @IBOutlet weak var passwordField: FancyField!
    
    var interstital: GADInterstitial!
    

    override func viewDidLoad() {
        super.viewDidLoad()
       
          interstital = GADInterstitial(adUnitID: "ca-app-pub-6678323998837443/5953429170")
        let request = GADRequest()
        interstital.load(request)
         interstital = creatAndLoadInterstial()
      //  interstital.delegate = self as! GADInterstitialDelegate
      //  self.emailField.delegate = self as! UITextFieldDelegate
       // self.passwordField.delegate = self as! UITextFieldDelegate
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: "dosmissKeyboard")
        
        view.addGestureRecognizer(tap)
        self.hideKeyboardWhenTappedAround()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        if let _ = KeychainWrapper.standard.string(forKey: KEY_UID) {
           performSegue(withIdentifier: "itworkedbefore", sender: nil)
        }
        
    }
    
    
    @IBAction func logInTapped(_ sender: Any) {
        if let email = emailField.text , let password = passwordField.text {
            Auth.auth().signIn(withEmail: email, password: password, completion: { (user,error) in
                if error == nil {
                    print("ALI: Succefllty signed in")
                    if self.interstital.isReady{
                        self.interstital.present(fromRootViewController: self)
                    } else {
                        print("AD wasn't ready")
                    }
                     self.performSegue(withIdentifier: "itworkedbefore", sender: nil)
                }else {
                    let alret = UIAlertController(title: "ERROR", message: "EMAIL OR PASSWORD IS INCROEECT", preferredStyle: UIAlertControllerStyle.alert)
                    
                    alret.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                    
                        self.present(alret, animated: true, completion: nil)
                }
            })
        }
    }
    
    @IBAction func SignInTapped(_ sender: Any) {
        if interstital.isReady{
            interstital.present(fromRootViewController: self)
        } else {
            print("AD wasn't ready")
        }
        performSegue(withIdentifier: "showit", sender: nil)
    }
    
    func creatAndLoadInterstial() -> GADInterstitial {
        let interstital = GADInterstitial(adUnitID: "ca-app-pub-6678323998837443/5953429170")
       // interstital.delegate as! GADInterstitialDelegate
        interstital.load(GADRequest())
        return interstital
    }
    
    func interstitalDidDismissScreen(_ ad: GADInterstitial) {
        interstital = creatAndLoadInterstial()
    }
    
    func dismissKeyboard() {
        view.endEditing(true)
    }
    
    
    
    
    
}
