//
//  RoundedImg.swift
//  get it sell it
//
//  Created by Ali Zuberi  on 2018-07-01.
//  Copyright © 2018 Ali Zuberi . All rights reserved.
//

import UIKit

extension UIImageView {
    
    
    func roundedImage() {
        self.layer.cornerRadius = self.frame.size.width / 2
        self.clipsToBounds = true
    }
}
