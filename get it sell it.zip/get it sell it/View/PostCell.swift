//
//  PostCell.swift
//  get it sell it
//
//  Created by Ali Zuberi  on 2018-03-12.
//  Copyright © 2018 Ali Zuberi . All rights reserved.
//

import UIKit
import Firebase

class PostCell: UITableViewCell {
    
    @IBOutlet weak var profileImg: UIImageView!
    @IBOutlet weak var username: UILabel!
    @IBOutlet weak var  postImg: UIImageView!
    @IBOutlet weak var likesLbl: UILabel!
    @IBOutlet weak var priceLbl: UILabel!
    @IBOutlet weak var caption:  UITextView!
        var post:Post!

    
   
    override func awakeFromNib() {
        super.awakeFromNib()
        
        
        
        
            }
       
    func configureCell(post: Post, img: UIImage? = nil) {
        self.post = post
        self.likesLbl.text = "\(post.likes)"
        if priceLbl != nil {
            self.priceLbl.text = "\(post.price)"
           print("it working price is working")
        } else {
            self.priceLbl.text = "\(post.price)"
        }
        self.priceLbl.text = "\(post.price)"
        self.username.text = post.title
        
       
        
        
        //  check if image is  in cache
        
        if img != nil {
            self.postImg.image = img
            
        } else {
            // downloading  image if not in cache
            
            
                let ref = Storage.storage().reference(forURL: post.imageUrl)
            
            // make sure is image is only 2 megabytes
            ref.getData(maxSize: 2 * 1024 * 1024, completion: { (data , error) in
               
                
                
                
                if error != nil {
                    //  if there is an error
                    print(" ALI:Unable to downald image ")
                } else {
                    print("ALI:image downlaed from storage")
                    
                    // downlading images and saving them to cache
                    if let imgData = data {
                        if let img = UIImage(data: imgData) {
                            self.postImg.image = img
                            FeedVC.imageCache.setObject(img, forKey: post.imageUrl as NSString)
                        
                        }
                    }
                    
                        
                        
                    }
                
                
                })
                    
                    
        }
        }

        }



        
        
        
        

    

    

