//
//  hideit.swift
//  get it sell it
//
//  Created by Ali Zuberi  on 2018-09-08.
//  Copyright © 2018 Ali Zuberi . All rights reserved.
//

import Foundation
import UIKit

class hide : UIViewController {
    override func viewDidLoad() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: "dismissKeyboard")
        view.addGestureRecognizer(tap)
    }
    
    
}

extension UIViewController{
    func hideKeyboardWhenTappedAround() {
        let tap : UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKEyboard))
        view.addGestureRecognizer(tap)
    }
    @objc func dismissKEyboard() {
        view.endEditing(true)
    }
}
